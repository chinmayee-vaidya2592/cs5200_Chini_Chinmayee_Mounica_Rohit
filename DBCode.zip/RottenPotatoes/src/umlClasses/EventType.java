package umlClasses;

public enum EventType {
	
	Play,
	Musical

}
