package umlClasses;

public enum ArtistType {
	
	Director,
	Actor,
	Musician
}
